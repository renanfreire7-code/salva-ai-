@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (
    py -3 -m salva_ai_v2 --data-dir "%USERPROFILE%\SalvaAiHeadshop_SemLogin_02"
) else (
    python -m salva_ai_v2 --data-dir "%USERPROFILE%\SalvaAiHeadshop_SemLogin_02"
)
if errorlevel 1 (
    echo.
    echo Nao foi possivel iniciar. Leia a mensagem acima.
    pause
)
endlocal
