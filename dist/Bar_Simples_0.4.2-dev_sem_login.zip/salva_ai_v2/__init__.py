"""Bar Simples: PDV local com dados independentes do legado."""
__version__ = "0.4.2-dev"
